import { build } from 'esbuild';
import { zipFunctions } from '@netlify/zip-it-and-ship-it';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
await rm('artifacts/functions', { recursive: true, force: true });
await mkdir('artifacts/functions', { recursive: true });
await mkdir('artifacts/function-source', { recursive: true });
await build({ entryPoints: ['netlify/functions/game.ts'], outfile: 'artifacts/function-source/game.mjs', bundle: true, platform: 'node', target: 'node22', format: 'esm' });
const result = await zipFunctions('artifacts/function-source', 'artifacts/functions', {
  basePath: process.cwd(),
  config: { '*': { nodeBundler: 'esbuild', nodeVersion: '22' } },
  manifest: 'artifacts/functions/manifest.json',
});
assert.equal(result.length, 1, 'Exactly one Function must be packaged');
assert.equal(result[0].name, 'game');
assert.equal(result[0].runtime, 'js');
const manifest = JSON.parse(await readFile('artifacts/functions/manifest.json', 'utf8'));
assert.equal(manifest.functions.length, 1);
// Absolute paths from the local packager are machine-specific. Keep a portable
// inspection manifest; Netlify builds deploy metadata afresh from source.
const portable = JSON.parse(JSON.stringify(manifest).replaceAll(process.cwd() + '/', ''));
await writeFile('artifacts/functions/manifest.json', JSON.stringify(portable, null, 2) + '\n');
await rm('artifacts/function-source', { recursive: true, force: true });
console.log('Verified packaged Function: game.zip (Node 22, standard route)');
