import { execFileSync } from 'node:child_process';
const run = args => execFileSync(process.execPath, args, { stdio: 'inherit' });
run(['node_modules/vite/bin/vite.js', 'build']);
run(['scripts/package-function.mjs']);
run(['--test', 'tests/game.test.mjs', 'tests/packaged.test.mjs']);
