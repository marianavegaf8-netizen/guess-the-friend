# Verification results

- Frozen lockfile dependency installation: passed.
- Vite production build: passed; HTML, CSS and JavaScript emitted in `dist/`.
- Official Netlify function packaging: passed; one Node 22, runtime API v2 Function named `game`.
- Packaged function extracted and executed with no project dependencies: passed.
- Nine automated checks: passed.

## Complete two-player, three-round game

The real Function and Netlify Blobs SDK were used with an HTTP storage fixture. The fixture enforces the SDK's strong endpoint and atomic `If-None-Match` / `If-Match` behavior. No in-memory room state exists in production code.

For the packaged Function test, Alex guessed correctly each round and Blair selected a decoy each round:

| Round | Alex correct-match points | Alex fooling points | Alex total | Blair total |
| --- | ---: | ---: | ---: | ---: |
| 1 | 100 | 50 | 150 | 0 |
| 2 | 100 | 50 | 300 | 0 |
| 3 | 100 | 50 | 450 | 0 |

The host advanced after the third reveal. The final phase was `finished`; Alex was the sole winner, 450–0.

A separate three-round game finished in a verified 250–250 tie. Simultaneous submissions and forced conditional-write conflicts were exercised. Repeated guesses and repeated state requests did not award duplicate points.

## Other checks

- Original five-round default.
- Three-player classic matching and rematch score reset.
- Eight-player capacity and concurrent joins.
- Host-only controls and stale-round rejection.
- Same-device session recovery.
- Deadline transitions with missing answers and no undeserved points.
- Hidden answer ownership, opaque decoy IDs, private session tokens.
- Read-only polling when no deadline transition is due.
- Storage failure surfaced instead of acknowledged as saved.
- Frontend calls `/.netlify/functions/game` directly.
- No custom function path, API redirect, helper function entries, SQL database, or long-running server.
- Packaged Function has no `node_modules` directory; dependencies are bundled into its JavaScript.
- Browser check of the production frontend: original visual layout, game-length selector, room creation, and live connection status passed. Screenshot: `preview.png`.

## Limits

Netlify's live hosting and Blobs service were not deployed or contacted with a user's account. The SDK's HTTP storage service was replaced by a strict local fixture for testing; the production build, source Function and extracted packaged Function were executed locally. Netlify supplies the real access context automatically after a signed-in Drop deployment.

The included Function ZIP is a verified inspection artifact. Upload the complete source project ZIP to signed-in Netlify Drop so Netlify builds and deploys the frontend and Function together.
