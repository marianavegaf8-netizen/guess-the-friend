import { getStore } from '@netlify/blobs';
import { handleGame } from '../../server/game.mjs';

// Netlify supplies Blobs access automatically in a deployed Function.
// Use the standard /.netlify/functions/game URL; no custom route config.
export default async function game(request: Request): Promise<Response> {
  return handleGame(request, () => getStore({
    name: 'who-said-that-rooms',
    consistency: 'strong',
  }));
}
