const prompts = [["What would be the worst thing to hear from your pilot?", "Has anyone seen my glasses?", "This is my first day."], ["What is your most useless superpower?", "Talking to bread.", "Invisibility, but only alone."], ["What would your autobiography be called?", "A Series of Snack Breaks", "I Meant to Do That"], ["What should never be a pizza topping?", "Toothpaste", "An entire second pizza"], ["What is a terrible name for a luxury hotel?", "The Last Resort", "Probably Haunted"], ["What would an alien misunderstand about humans?", "Why we pay to run indoors.", "Our emotional support water bottles."], ["What is the worst thing to bring to a first date?", "A PowerPoint about myself.", "My entire family."], ["What would your pet say about you?", "Needs more training.", "Excellent snack dispenser."]];
const shuffle = (a) => a.map((v) => ({ v, k: Math.random() })).sort((a2, b) => a2.k - b.k).map((x) => x.v);
function begin(r) {
  r.round++;
  r.phase = "answer";
  r.deadline = Date.now() + 45e3;
  r.answers = {};
  r.guesses = {};
  r.cards = [];
  r.delta = {};
  r.prompt = r.prompts[r.round - 1];
}
function guessing(r) {
  r.phase = "guess";
  r.deadline = Date.now() + 6e4;
  r.cards = shuffle(r.players.filter((p) => r.answers[p.id]).map((p) => ({ id: crypto.randomUUID(), author: p.id, text: r.answers[p.id] })));
  if (r.players.length === 2) {
    r.options = {};
    for (const p of r.players) {
      const opponent = r.players.find((q) => q.id !== p.id);
      r.options[p.id] = r.answers[opponent.id] ? shuffle([{ id: crypto.randomUUID(), author: opponent.id, text: r.answers[opponent.id] }, ...r.prompt.slice(1).map((text, i) => ({ id: crypto.randomUUID(), author: null, text }))]) : [];
    }
  }
}
function reveal(r) {
  r.phase = "reveal";
  r.deadline = null;
  for (const p of r.players) r.delta[p.id] = { correct: 0, fooled: 0, total: 0 };
  for (const p of r.players) {
    const g = r.guesses[p.id] || {};
    if (r.players.length === 2) {
      const other = r.players.find((q) => q.id !== p.id);
      if (r.answers[other.id] && g.choice) {
        if (g.choice === other.id) r.delta[p.id].correct++;
        else r.delta[other.id].fooled++;
      }
    } else for (const c of r.cards) {
      if (c.author === p.id || !g[c.id]) continue;
      if (g[c.id] === c.author) r.delta[p.id].correct++;
      else r.delta[c.author].fooled++;
    }
  }
  for (const p of r.players) {
    const d = r.delta[p.id];
    d.total = d.correct * 100 + d.fooled * 50;
    p.score += d.total;
  }
}
function tick(r) {
  if (r.phase === "answer" && (Date.now() >= r.deadline || r.players.every((p) => r.answers[p.id]))) guessing(r);
  if (r.phase === "guess" && (Date.now() >= r.deadline || r.players.every((p) => r.guesses[p.id]))) reveal(r);
}
function view(r, id) {
  const p = r.players.find((p2) => p2.id === id);
  if (!p) throw Error("Your seat was not found. Rejoin on your original device.");
  return { code: r.code, totalRounds: r.totalRounds, phase: r.phase, round: r.round, prompt: r.prompt?.[0], deadline: r.deadline, host: r.host === id, me: id, players: r.players.map((p2) => ({ id: p2.id, name: p2.name, score: p2.score, answered: !!r.answers[p2.id], guessed: !!r.guesses[p2.id] })), myAnswer: r.answers[id], myGuesses: r.guesses[id], cards: r.cards.map((c) => r.phase === "reveal" ? c : { id: c.id, text: c.text, mine: c.author === id }), options: r.phase === "guess" || r.phase === "reveal" ? r.options?.[id]?.map((c) => r.phase === "reveal" ? c : { id: c.id, text: c.text }) : void 0, delta: r.phase === "reveal" ? r.delta : null, reveals: r.phase === "reveal" ? r.players.map((p2) => ({ name: p2.name, guesses: r.guesses[p2.id] })) : null };
}
export {
  begin,
  prompts,
  shuffle,
  tick,
  view
};
