import { begin, tick, view, prompts, shuffle } from './rounds.mjs';

const ROOM_LIFETIME = 24 * 60 * 60 * 1000;
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const response = (data, status = 200) => Response.json(data, {
  status,
  headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' },
});
class GameError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const fail = (message, status) => { throw new GameError(message, status); };
const nickname = value => {
  if (typeof value !== 'string' || !value.trim()) fail('Enter a nickname.');
  return value.trim().slice(0, 20);
};

// One room is one atomic document. Recompute from the latest strong read after
// a lost conditional write. Never apply an increment to a stale document.
export async function handleGame(request, getStore) {
  try {
    if (!['GET', 'POST'].includes(request.method)) {
      return response({ error: 'Use GET or POST.' }, 405);
    }
    const url = new URL(request.url);
    if (url.pathname !== '/.netlify/functions/game') fail('Endpoint not found.', 404);
    if (Number(request.headers.get('content-length') || 0) > 8192) fail('Request is too large.', 413);
    let body = {};
    if (request.method === 'POST') {
      const text = await request.text();
      if (text.length > 8192) fail('Request is too large.', 413);
      try { body = JSON.parse(text); } catch { fail('Invalid request.'); }
      if (!body || typeof body !== 'object' || Array.isArray(body)) fail('Invalid request.');
    }
    const operation = body.operation || url.searchParams.get('operation') || 'state';
    if (!['create', 'join', 'state', 'action'].includes(operation)) fail('Unknown operation.');
    if (operation !== 'state' && request.method !== 'POST') fail('Use POST for this operation.', 405);
    const store = getStore();

    if (operation === 'create') {
      const name = nickname(body.name);
      const totalRounds = body.rounds === undefined ? 5 : Number(body.rounds);
      if (![3, 5].includes(totalRounds)) fail('Choose 3 or 5 rounds.');
      const token = crypto.randomUUID();
      const id = crypto.randomUUID();
      for (let attempt = 0; attempt < 8; attempt++) {
        const code = Array.from(crypto.getRandomValues(new Uint8Array(5)),
          byte => ALPHABET[byte % ALPHABET.length]).join('');
        const room = {
          code, host: id, totalRounds, phase: 'lobby', round: 0,
          players: [{ id, token, name, score: 0 }], answers: {}, guesses: {}, cards: [],
          prompts: shuffle(prompts).slice(0, totalRounds),
          expiresAt: Date.now() + ROOM_LIFETIME,
        };
        const result = await store.setJSON(code, room, { onlyIfNew: true });
        if (result.modified && !result.etag) throw new Error('Storage did not confirm the write.');
        if (result.modified) return response({ id: token, room: view(room, id) });
      }
      fail('Could not create a room. Try again.', 409);
    }

    const code = String(body.code || url.searchParams.get('code') || '').trim().toUpperCase();
    if (!/^[A-Z]{5}$/.test(code)) fail('Enter a five-letter room code.');
    const token = body.id || url.searchParams.get('id');
    // Generate the joining seat once, so retries cannot change its identity.
    const joining = operation === 'join'
      ? { id: crypto.randomUUID(), token: crypto.randomUUID(), name: nickname(body.name), score: 0 }
      : null;

    for (let attempt = 0; attempt < 10; attempt++) {
      const entry = await store.getWithMetadata(code, { type: 'json', consistency: 'strong' });
      if (!entry || entry.data.expiresAt <= Date.now()) {
        fail('Room not found. Check the code or create a new room.', 404);
      }
      const room = entry.data;
      const before = JSON.stringify(room);
      const player = joining || room.players.find(player => player.token === token);
      if (!player) fail('Session not found. Rejoin on your original device.', 401);
      const id = player.id;
      tick(room);
      if (joining) {
        if (room.phase !== 'lobby') fail('This game has started. Rejoin from your original device.');
        if (room.players.length >= 8) fail('This room is full.');
        if (room.players.some(p => p.name.toLowerCase() === joining.name.toLowerCase())) {
          fail('That nickname is taken. Pick another.');
        }
        room.players.push(joining);
      } else if (operation === 'action') {
        applyAction(room, id, body);
        tick(room);
      }
      // Polling is read-only unless a deadline advances the game.
      if (JSON.stringify(room) === before) {
        return response({ id: token, room: view(room, id) });
      }
      const result = await store.setJSON(code, room, { onlyIfMatch: entry.etag });
      if (result.modified && !result.etag) throw new Error('Storage did not confirm the write.');
      if (result.modified) {
        return response({ id: joining?.token || token, room: view(room, id) });
      }
      // Another invocation won. Read again and revalidate the command, including
      // its expected round, to avoid double scoring or skipping a round.
    }
    return response({ error: 'Room is busy. Please try again.' }, 409);
  } catch (error) {
    if (error instanceof GameError) return response({ error: error.message }, error.status);
    return response({ error: 'The room service is temporarily unavailable. Please try again.' }, 503);
  }
}

function applyAction(room, id, body) {
  const { action } = body;
  if (!['start', 'next', 'again', 'answer', 'guess'].includes(action)) fail('Unknown action.');
  // An old request cannot affect the following round or a rematch.
  if (body.round !== room.round) fail('The round changed. Refresh your game and try again.', 409);
  if (['start', 'next', 'again'].includes(action)) {
    if (id !== room.host) fail('Only the host can do that.', 403);
    if (action === 'start' && room.phase === 'lobby') {
      if (room.players.length < 2) fail('At least two players are needed.');
      begin(room);
    } else if (action === 'next' && room.phase === 'reveal') {
      if (room.round === room.totalRounds) room.phase = 'finished';
      else begin(room);
    } else if (action === 'again' && room.phase === 'finished') {
      room.round = 0;
      room.players.forEach(p => { p.score = 0; });
      room.prompts = shuffle(prompts).slice(0, room.totalRounds);
      begin(room);
    }
    return;
  }
  if (action === 'answer') {
    if (room.phase !== 'answer' || room.answers[id]) return;
    if (typeof body.answer !== 'string' || !body.answer.trim()) fail('Write an answer first.');
    room.answers[id] = body.answer.trim().slice(0, 160);
    return;
  }
  if (room.phase !== 'guess' || room.guesses[id]) return;
  const guesses = body.guesses;
  if (!guesses || typeof guesses !== 'object' || Array.isArray(guesses)) fail('Choose your guesses.');
  if (room.players.length === 2) {
    if (!room.options[id].length) { room.guesses[id] = {}; return; }
    const option = room.options[id].find(option => option.id === guesses.choice);
    if (!option) fail('Choose an answer.');
    room.guesses[id] = { choice: option.author || 'decoy' };
  } else {
    const eligible = room.cards.filter(card => card.author !== id);
    const values = eligible.map(card => guesses[card.id]);
    if (values.some(value => !room.players.some(p => p.id === value && value !== id)) ||
        new Set(values).size !== values.length) {
      fail('Match each answer to a different player.');
    }
    room.guesses[id] = Object.fromEntries(eligible.map(card => [card.id, guesses[card.id]]));
  }
}
