import test from 'node:test';
import assert from 'node:assert/strict';
import { installBlobsFixture } from './blobs-fixture.mjs';
import { call, createPair, playThreeRounds } from './scenarios.mjs';

test('complete 3-round two-player game: decoys, scoring, shared final winners, CAS retries', async () => {
  await playThreeRounds();
});

test('unique final winner across three rounds', async () => {
  const f = installBlobsFixture();
  try {
    const [a, b] = await createPair();
    await call('action', { ...a, action: 'start', round: 0 });
    let result;
    for (let round = 1; round <= 3; round++) {
      await call('action', { ...a, action: 'answer', round, answer: 'Alex ' + round });
      await call('action', { ...b, action: 'answer', round, answer: 'Blair ' + round });
      for (const [p, text, correct] of [[a, 'Blair ' + round, true], [b, 'Alex ' + round, false]]) {
        const v = (await call('state', p)).room;
        const option = v.options.find(o => (o.text === text) === correct);
        await call('action', { ...p, action: 'guess', round, guesses: { choice: option.id } });
      }
      result = await call('action', { ...a, action: 'next', round });
    }
    assert.equal(result.room.phase, 'finished');
    assert.deepEqual(result.room.players.map(p => p.score), [450, 0]);
    assert.equal(result.room.players.reduce((a, b) => a.score > b.score ? a : b).name, 'Alex');
  } finally { f.restore(); }
});

test('default five-round game, host permissions, reconnect and read-only polling', async () => {
  const f = installBlobsFixture();
  try {
    const a = await call('create', { name: 'Host' });
    assert.equal(a.room.totalRounds, 5);
    const host = { id: a.id, code: a.room.code };
    const b = await call('join', { name: 'Guest', code: a.room.code });
    await call('action', { id: b.id, code: a.room.code, action: 'start', round: 0 }, 403);
    await call('state', { ...host, id: 'bad-session' }, 401);
    const writes = f.requests.filter(r => r.method === 'PUT').length;
    const reconnect = await call('state', host);
    assert.equal(reconnect.room.me, a.room.me);
    assert.equal(f.requests.filter(r => r.method === 'PUT').length, writes);
    await call('action', { ...host, action: 'start', round: 0 });
    await call('action', { ...host, action: 'next', round: 0 }, 409);
    assert.equal(f.room(host.code).round, 1);
  } finally { f.restore(); }
});

test('server deadlines, missing answers and duplicate reveal do not award points', async () => {
  const f = installBlobsFixture();
  try {
    const [a] = await createPair();
    await call('action', { ...a, action: 'start', round: 0 });
    f.edit(a.code, r => { r.deadline = Date.now() - 1; });
    const g = await call('state', a);
    assert.equal(g.room.phase, 'guess');
    assert.deepEqual(g.room.options, []);
    f.edit(a.code, r => { r.deadline = Date.now() - 1; });
    const results = await Promise.all([call('state', a), call('state', a)]);
    assert.ok(results.every(r => r.room.phase === 'reveal'));
    assert.deepEqual(results[0].room.players.map(p => p.score), [0, 0]);
  } finally { f.restore(); }
});

test('simultaneous joins preserve all seats and enforce the eight-player limit', async () => {
  const f = installBlobsFixture();
  try {
    const a = await call('create', { name: 'Host' });
    await Promise.all(Array.from({ length: 7 }, (_, i) => call('join', { code: a.room.code, name: 'Guest ' + i })));
    assert.equal(f.room(a.room.code).players.length, 8);
    await call('join', { code: a.room.code, name: 'Ninth' }, 400);
  } finally { f.restore(); }
});

test('failed storage writes are reported, never acknowledged as saved', async () => {
  const f = installBlobsFixture();
  try {
    f.failWrites();
    await call('create', { name: 'Host' }, 503);
    assert.equal(f.rows.size, 0);
  } finally { f.restore(); }
});

test('three-player anonymous matching preserves classic scoring and rematches', async () => {
  const f = installBlobsFixture();
  try {
    const a = await call('create', { name: 'One', rounds: 3 });
    const players = [{ id: a.id, code: a.room.code }];
    for (const name of ['Two', 'Three']) {
      const p = await call('join', { name, code: a.room.code });
      players.push({ id: p.id, code: a.room.code });
    }
    await call('action', { ...players[0], action: 'start', round: 0 });
    let result;
    for (let round = 1; round <= 3; round++) {
      for (let i = 0; i < players.length; i++) {
        await call('action', { ...players[i], action: 'answer', round, answer: 'Answer ' + i });
      }
      const stored = f.room(a.room.code);
      for (let i = 0; i < players.length; i++) {
        const v = await call('state', players[i]);
        const guesses = Object.fromEntries(stored.cards.filter(c => c.author !== v.room.me).map(c => [c.id, c.author]));
        await call('action', { ...players[i], action: 'guess', round, guesses });
      }
      result = await call('state', players[0]);
      assert.deepEqual(result.room.players.map(p => p.score), [round * 200, round * 200, round * 200]);
      result = await call('action', { ...players[0], action: 'next', round });
    }
    assert.equal(result.room.phase, 'finished');
    result = await call('action', { ...players[0], action: 'again', round: 3 });
    assert.equal(result.room.phase, 'answer');
    assert.equal(result.room.round, 1);
    assert.deepEqual(result.room.players.map(p => p.score), [0, 0, 0]);
  } finally { f.restore(); }
});
