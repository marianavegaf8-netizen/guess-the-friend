import assert from 'node:assert/strict';
import game from '../netlify/functions/game.ts';
import { installBlobsFixture } from './blobs-fixture.mjs';

export function request(operation, data = {}) {
  return new Request('https://game.test/.netlify/functions/game', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operation, ...data }),
  });
}
export async function call(operation, data, status = 200, handler = game) {
  const res = await handler(request(operation, data));
  const result = await res.json();
  assert.equal(res.status, status, JSON.stringify(result));
  assert.equal(res.headers.get('cache-control'), 'no-store');
  return result;
}
export async function createPair(rounds = 3) {
  const a = await call('create', { name: 'Alex', rounds });
  const b = await call('join', { name: 'Blair', code: a.room.code });
  return [{ id: a.id, code: a.room.code }, { id: b.id, code: a.room.code }];
}

// This exported scenario is also run against the extracted packaged Function.
export async function playThreeRounds(handler = game, singleWinner = false) {
  const fixture = installBlobsFixture();
  try {
    const callGame = (op, data, status = 200) => call(op, data, status, handler);
    const created = await callGame('create', { name: 'Alex', rounds: 3 });
    const joined = await callGame('join', { name: 'Blair', code: created.room.code });
    const a = { id: created.id, code: created.room.code };
    const b = { id: joined.id, code: created.room.code };
    let state = (await callGame('action', { ...a, action: 'start', round: 0 })).room;
    const totals = singleWinner ? [[150, 0], [300, 0], [450, 0]] : [[150, 0], [250, 100], [250, 250]];
    for (let round = 1; round <= 3; round++) {
      assert.equal(state.phase, 'answer');
      assert.equal(state.round, round);
      assert.equal(state.totalRounds, 3);
      // Both invocations read the same version; one must safely retry.
      await Promise.all([a, b].map((p, i) => callGame('action', {
        ...p, action: 'answer', round, answer: (i === 0 ? 'Alex' : 'Blair') + ' answer ' + round,
      })));
      const va = (await callGame('state', a)).room;
      const vb = (await callGame('state', b)).room;
      assert.equal(va.phase, 'guess');
      assert.equal(va.options.length, 3);
      assert.ok(va.options.every(o => !('author' in o)));
      assert.ok(va.cards.every(o => !('author' in o)));
      assert.ok(!JSON.stringify(va).includes(b.id), 'Other player’s session token is never public');
      const choice = (v, realText, correct) => v.options.find(o => (o.text === realText) === correct).id;
      // R1 Alex correct, Blair fooled. R2 both correct. R3 Alex fooled, Blair correct.
      const guesses = [
        { choice: choice(va, 'Blair answer ' + round, (singleWinner || round !== 3)) },
        { choice: choice(vb, 'Alex answer ' + round, (!singleWinner && round !== 1)) },
      ];
      fixture.conflictOnce();
      await Promise.all([a, b].map((p, i) => callGame('action', { ...p, action: 'guess', round, guesses: guesses[i] })));
      state = (await callGame('state', a)).room;
      assert.equal(state.phase, 'reveal');
      assert.deepEqual(state.players.map(p => p.score), totals[round - 1]);
      assert.equal(state.cards.length, 2);
      // Retried submission and polling must never score a second time.
      await callGame('action', { ...a, action: 'guess', round, guesses: guesses[0] });
      const repeated = await callGame('state', a);
      assert.deepEqual(repeated.room.players.map(p => p.score), totals[round - 1]);
      state = (await callGame('action', { ...a, action: 'next', round })).room;
    }
    assert.equal(state.phase, 'finished');
    assert.deepEqual(state.players.map(p => p.score), singleWinner ? [450, 0] : [250, 250]);
    const highest = Math.max(...state.players.map(p => p.score));
    assert.deepEqual(state.players.filter(p => p.score === highest).map(p => p.name), singleWinner ? ['Alex'] : ['Alex', 'Blair']);
    assert.ok(fixture.conflicts >= 3, 'Conditional-write conflicts were exercised');
    return { final: state, conflicts: fixture.conflicts };
  } finally { fixture.restore(); }
}

