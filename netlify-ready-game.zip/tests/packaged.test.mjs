import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { playThreeRounds } from './scenarios.mjs';

test('production frontend points directly to the standard function URL', async () => {
  const html = await readFile('dist/index.html', 'utf8');
  assert.ok(html.includes('Who Said That?'));
  const files = await readdir('dist/assets');
  const js = await readFile(join('dist/assets', files.find(f => f.endsWith('.js'))), 'utf8');
  assert.ok(js.includes('/.netlify/functions/game'));
  assert.ok(!js.includes('/api/'));
  assert.ok(!js.includes('cloudflare'));
  const functionFiles = await readdir('netlify/functions');
  assert.deepEqual(functionFiles, ['game.ts']);
  const entry = await readFile('netlify/functions/game.ts', 'utf8');
  assert.ok(!entry.includes('config.path'));
  assert.ok(!entry.includes('export const config'));
  const config = await readFile('netlify.toml', 'utf8');
  assert.ok(!config.includes('[[redirects]]'));
});

test('packaged function is self-contained and completes the same three-round game', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'wst-function-'));
  try {
    execFileSync('unzip', ['-q', 'artifacts/functions/game.zip', '-d', dir]);
    const files = await readdir(dir);
    assert.ok(!files.includes('node_modules'));
    assert.ok(files.includes('___netlify-bootstrap.mjs'));
    const metadata = JSON.parse(await readFile(join(dir, '___netlify-metadata.json'), 'utf8'));
    assert.equal(metadata.version, 1);
    const manifest = JSON.parse(await readFile('artifacts/functions/manifest.json', 'utf8'));
    assert.equal(manifest.functions[0].buildData.runtimeAPIVersion, 2);
    const packaged = await import(pathToFileURL(join(dir, 'game.mjs')));
    assert.equal(typeof packaged.default, 'function');
    const result = await playThreeRounds(packaged.default, true);
    assert.equal(result.final.phase, 'finished');
    assert.deepEqual(result.final.players.map(p => p.score), [450, 0]);
  } finally { await rm(dir, { recursive: true, force: true }); }
});
