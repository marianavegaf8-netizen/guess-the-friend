import assert from 'node:assert/strict';

// Emulate only Netlify's HTTP storage service. Tests execute the real Function,
// real SDK, strong-read routing and conditional HTTP writes.
export function installBlobsFixture() {
  const originalFetch = globalThis.fetch;
  const previousContext = globalThis.netlifyBlobsContext;
  const rows = new Map();
  const requests = [];
  let version = 0, conflicts = 0, forceConflict = false, failWrites = false;
  globalThis.netlifyBlobsContext = Buffer.from(JSON.stringify({
    siteID: 'test-site', token: 'fixture-only',
    edgeURL: 'https://eventual.blobs.test',
    uncachedEdgeURL: 'https://strong.blobs.test',
  })).toString('base64');
  globalThis.fetch = async (input, init = {}) => {
    const url = new URL(input instanceof Request ? input.url : input);
    assert.equal(url.origin, 'https://strong.blobs.test', 'Every storage operation must use strong consistency');
    const key = decodeURIComponent(url.pathname.split('/').at(-1));
    const method = String(init.method || 'GET').toUpperCase();
    const headers = new Headers(init.headers);
    requests.push({ method, key, match: headers.get('if-match'), fresh: headers.get('if-none-match') });
    if (method === 'GET') {
      const row = rows.get(key);
      return row ? new Response(row.body, { headers: { etag: row.etag, 'content-type': 'application/json' } })
        : new Response(null, { status: 404 });
    }
    assert.equal(method, 'PUT');
    assert.ok(headers.has('if-match') || headers.get('if-none-match') === '*', 'Every write must be conditional');
    if (failWrites) return new Response('Storage failure', { status: 400 });
    if (forceConflict && headers.has('if-match')) {
      forceConflict = false; conflicts++;
      return new Response(null, { status: 412 });
    }
    const row = rows.get(key);
    if ((headers.get('if-none-match') === '*' && row) ||
        (headers.has('if-match') && headers.get('if-match') !== row?.etag)) {
      conflicts++; return new Response(null, { status: 412 });
    }
    const etag = '"version-' + (++version) + '"';
    rows.set(key, { body: String(init.body), etag });
    return new Response(null, { status: 200, headers: { etag } });
  };
  return {
    requests, rows,
    get conflicts() { return conflicts; },
    conflictOnce() { forceConflict = true; },
    failWrites() { failWrites = true; },
    room(code) { return JSON.parse(rows.get(code).body); },
    edit(code, change) { const row = rows.get(code); const room = JSON.parse(row.body); change(room); rows.set(code, { body: JSON.stringify(room), etag: '"version-' + (++version) + '"' }); },
    restore() { globalThis.fetch = originalFetch; globalThis.netlifyBlobsContext = previousContext; },
  };
}
