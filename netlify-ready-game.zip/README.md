# Who Said That? — Netlify-ready game

## Publish using your browser

1. Sign in to your Netlify account.
2. Open https://app.netlify.com/drop.
3. Drop **netlify-ready-game.zip** (this entire source project) onto the page.
4. Wait for Netlify to install the locked dependencies, build the frontend, and deploy the Function. Open the resulting Netlify URL, create a room, and share its code with friends.

If your browser extracts ZIP downloads automatically, drop the extracted project folder containing `netlify.toml` and `package.json` instead. Upload the whole project, not only `dist` or the Function ZIP.

Signing in is essential: Netlify's signed-in Drop flow builds source projects. Anonymous static-only uploads do not build the Function. Netlify supplies Blobs access automatically; no repository, command line, user-entered environment variables, API keys, or database setup are needed. Project visibility follows your Netlify team's settings; friends need access to the published URL.

Netlify's documented Drop flow: https://docs.netlify.com/start/quickstarts/netlify-drop-quickstart/

## Gameplay

The original design, 2–8-player room-code joining, timers, anonymous answers, reveals, host controls, rejoining from the same device, scoring and rematches are preserved. Five rounds remain the default. The host can also choose a three-round quick game when creating a room.

Each round has 45 seconds to answer and 60 seconds to guess. Correct matches earn 100 points; each player fooled earns the author 50 points. Two-player games mix the opponent's answer with two decoys. Missing answers are excluded. The host advances after reveals and displays the final winner after the last round. Ties share victory.

## Included files

- `index.html`, `src/`: frontend source, original styling and direct Function calls.
- `netlify.toml`: build, publish directory and standard Function configuration.
- `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`: pinned build dependencies and build-script permissions.
- `netlify/functions/game.ts`: the only Function entry point.
- `server/`: helpers, game rules and Blobs room operations, outside the Functions directory.
- `dist/`: verified production frontend output.
- `artifacts/functions/game.zip`: verified self-contained Function artifact, including Netlify's bootstrap. This is an inspection artifact, not a separate upload step.
- `tests/`: complete-game, privacy, concurrency, failure and packaging checks.
- `VERIFICATION.md`: exact test results and verification limits.

There are no API redirects or custom `config.path` routes. All frontend requests go directly to `/.netlify/functions/game`.

## Storage and concurrency

The Function opens the site-wide `who-said-that-rooms` Blobs store with strong consistency. Room creation uses `onlyIfNew`; room changes use `onlyIfMatch` with the ETag from a strong read. Conflicts cause a bounded retry from fresh state. Host commands carry the expected round, preventing delayed requests from skipping rounds. Scores and phase changes commit together in one room document. Ordinary polling does not write unless a deadline advances the phase.

No process must stay running. Browsers poll every 1.5 seconds; server-side deadlines advance on requests. Private session tokens are stored only on the player's device and in the server-side room document. Public player IDs are separate. Rooms become inaccessible 24 hours after creation; this is application expiry, not automatic physical deletion of blobs.

## Verification

The included checks use the real Netlify Blobs SDK and a local HTTP storage fixture enforcing strong-read routing and ETag preconditions. They also extract and execute the packaged Function through complete gameplay. This package has not been deployed to a Netlify account in this task; live Netlify provisioning is not claimed.
