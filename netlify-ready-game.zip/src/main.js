function readSession() {
  try {
    return JSON.parse(localStorage.getItem("wst-session") || "null");
  } catch {
    return null;
  }
}
let session = readSession(), room = null, busy = false, guess = {}, error = "", screen = "home";
const app = document.getElementById("app");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
async function api(path, data) {
  const res = await fetch("/.netlify/functions/game", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...data, operation: path }) });
  const d = await res.json();
  if (!res.ok) throw Error(d.error || "Connection failed.");
  return d;
}
function rules() {
  return "<details><summary>How to play & scoring</summary><p>3 or 5 rounds (host chooses). Write an answer in 45 seconds. Match anonymous answers to players in 60 seconds. Each player can be used once; your answer is filled in.</p><p>100 points per correct match + 50 points for every player you fool. No speed bonuses. Highest total wins; ties share victory. The host advances after each reveal.</p><p>With 2 players, find your opponent\u2019s real answer among two decoys. Missing answers are excluded. Rejoin on the same device after a disconnect.</p></details>";
}
function render() {
  if (!room) {
    app.innerHTML = '<div class="hero"><div><div class="eyebrow">THE WHO-KNOWS-YOU-BEST PARTY GAME</div><h1>Your friends.<br>Their answers.<br><em>Your best guess.</em></h1><p class="intro">Think you know your people? Answer a weird prompt. Hide in plain sight. Find out who said what.</p><div class="tags"><span>\u25C9 2\u20138 players</span><span>\u25F7 About 15 minutes</span><span>\u2726 Endless inside jokes</span></div></div><div class="art" aria-label="Playful speech bubbles"><div class="spark">\u2733</div><div class="bubble b1"><span class="eyes">\u25D5 \u25D5</span>Definitely not me.</div><div class="bubble b2">That is SO you. \u2197</div><div class="bubble b3">Okay\u2026 who said that? \u{1F440}</div></div></div><div class="play"><form class="panel host" id="create"><div class="small">MAKE IT A GAME NIGHT</div><h2>Start the party <span style="float:right">\u2197</span></h2><p>Create a room, share the code, gather your suspects.</p><div class="row"><input aria-label="Your nickname" name="name" placeholder="Your nickname" maxlength="20" required><button class="btn">Create a room \u2192</button></div><label class="round-picker">Game length <select name="rounds" aria-label="Game length"><option value="5">5 rounds \xB7 Classic</option><option value="3">3 rounds \xB7 Quick game</option></select></label></form><form class="panel" id="join"><div class="small">GOT AN INVITE?</div><h2>You\u2019re in good company.</h2><p>Enter your nickname and the room code to jump in.</p><div class="row"><input aria-label="Your nickname" name="name" placeholder="Nickname" maxlength="20" required><input class="joincode" aria-label="Room code" name="code" placeholder="CODE" maxlength="5" value="' + esc(new URLSearchParams(location.search).get("room") || "") + '" required><button class="btn">Join \u2192</button></div></form></div><div class="how"><strong>THE PLOT, IN THREE ACTS</strong><span class="step"><b>01</b> Write something unexpected.</span><span class="step"><b>02</b> Match the answer to the friend.</span><span class="step"><b>03</b> Reveal. Laugh. Repeat.</span></div>' + rules() + (error ? '<div class="error" role="alert">' + esc(error) + "</div>" : "");
    for (const type of ["create", "join"]) document.getElementById(type).onsubmit = async (e) => {
      e.preventDefault();
      if (busy) return;
      busy = true;
      const button = e.target.querySelector("button");
      button.disabled = true;
      try {
        const d = await api(type, Object.fromEntries(new FormData(e.target)));
        session = { id: d.id, code: d.room.code };
        localStorage.setItem("wst-session", JSON.stringify(session));
        room = d.room;
        error = "";
        render();
      } catch (e2) {
        error = e2.message;
        render();
      } finally {
        busy = false;
      }
    };
    return;
  }
  const r = room;
  let s = '<div class="game"><div class="topline"><div><div class="small">ROOM CODE</div><span class="code">' + r.code + '</span><button class="mini" id="copy">Copy invite</button></div><div>' + (r.deadline ? '<span class="timer" id="timer"></span>' : '<span class="pill">' + (r.phase === "lobby" ? "THE PARTY IS GATHERING" : r.phase === "finished" ? "THAT\u2019S A WRAP" : "ROUND " + r.round + " / " + r.totalRounds) + "</span>") + "</div></div>";
  if (r.phase === "lobby") {
    s += '<div class="eyebrow">EVERY GREAT STORY STARTS WITH A GROUP CHAT</div><h2 style="font-size:40px">Meet your suspects.</h2><p class="muted">Share the invite and join on your own devices. ' + r.players.length + ' of 8 seats filled.</p><div class="players">' + r.players.map((p, i) => '<div class="player"><span class="avatar">' + esc(p.name[0].toUpperCase()) + "</span><strong>" + esc(p.name) + "</strong><small>" + (p.id === r.me ? "You" : "Ready") + "</small></div>").join("") + "</div>" + (r.host ? '<button class="btn primary" id="start" ' + (r.players.length < 2 ? "disabled" : "") + ">Let\u2019s play \u2192</button>" : '<div class="wait">Waiting for the host to start\u2026</div>') + '<p class="muted">' + (r.players.length < 2 ? "One more friend and you\u2019re ready." : "Everyone\u2019s in? The host can start whenever you\u2019re ready.") + "</p>" + rules();
  }
  if (r.phase === "answer") {
    s += '<div class="eyebrow">ROUND ' + r.round + " OF " + r.totalRounds + ' \xB7 WRITE YOUR ANSWER</div><div class="prompt">' + esc(r.prompt) + "</div>" + (r.myAnswer ? '<div class="wait"><h2>Your secret is safe.</h2><p>\u201C' + esc(r.myAnswer) + "\u201D</p><span>" + r.players.filter((p) => p.answered).length + " / " + r.players.length + " answers in. Waiting for the others\u2026</span></div>" : '<form id="answer"><textarea name="answer" maxlength="160" placeholder="Make it sound like anyone but you\u2026" aria-label="Your answer" required></textarea><div class="row" style="justify-content:space-between;margin-top:15px"><span class="muted">160 characters. Make them count.</span><button class="btn primary">Lock in my answer \u2192</button></div></form>');
  }
  if (r.phase === "guess") {
    s += '<div class="eyebrow">ROUND ' + r.round + " OF " + r.totalRounds + ' \xB7 FOLLOW YOUR SUSPICIONS</div><div class="prompt">' + esc(r.prompt) + "</div>";
    if (r.myGuesses) s += '<div class="wait"><h2>Guesses locked.</h2><p>Time to see how well you know your people.</p>' + r.players.filter((p) => p.guessed).length + " / " + r.players.length + " players ready</div>";
    else if (r.players.length === 2) {
      s += '<p class="muted">Which answer did your opponent write? The other two are decoys.</p>' + r.options.map((c) => '<button class="choice ' + (guess.choice === c.id ? "selected" : "") + '" data-choice="' + c.id + '">' + esc(c.text) + "</button>").join("") + (!r.options.length ? "<p>No answer from your opponent this round.</p>" : "") + '<button class="btn primary" id="lock">Lock in my guess \u2192</button>';
    } else {
      s += '<p class="muted">Match each answer to a different friend. Your answer is already filled in.</p>' + r.cards.map((c) => '<div class="card">\u201C' + esc(c.text) + "\u201D" + (c.mine ? '<p class="muted">You wrote this one \u2713</p>' : '<select aria-label="Who wrote ' + esc(c.text) + '?" data-card="' + c.id + '"><option value="">Who said that?</option>' + r.players.filter((p) => p.id !== r.me).map((p) => '<option value="' + p.id + '" ' + (guess[c.id] === p.id ? "selected" : "") + ">" + esc(p.name) + "</option>").join("") + "</select>") + "</div>").join("") + '<button class="btn primary" id="lock">Lock in my guesses \u2192</button>';
    }
  }
  if (r.phase === "reveal") {
    s += '<div class="eyebrow">ROUND ' + r.round + " OF " + r.totalRounds + ' \xB7 THE TRUTH COMES OUT</div><div class="prompt">' + esc(r.prompt) + "</div>" + r.cards.map((c) => '<div class="card">\u201C' + esc(c.text) + '\u201D<p style="color:var(--purple);font-weight:700">\u2014 ' + esc(r.players.find((p) => p.id === c.author)?.name) + '</p><div class="muted">' + r.players.filter((p) => p.id !== c.author).map((p) => {
      const g = r.reveals.find((x) => x.name === p.name)?.guesses;
      const v = r.players.length === 2 ? g?.choice : g?.[c.id];
      return esc(p.name) + ": " + (v ? esc(r.players.find((q) => q.id === v)?.name || "a decoy") : "no guess");
    }).join(" \xB7 ") + "</div></div>").join("") + "<h2>The scoreboard</h2>" + scores(r, true) + (r.host ? '<button class="btn primary" id="next">' + (r.round === r.totalRounds ? "Show the winner \u2726" : "Next round \u2192") + "</button>" : '<p class="wait">Waiting for the host to continue\u2026</p>');
  }
  if (r.phase === "finished") {
    const high = Math.max(...r.players.map((p) => p.score));
    s += '<div class="finish">\u2737</div><div class="eyebrow" style="text-align:center">THE PEOPLE HAVE BEEN DECEIVED</div><h2 style="font-size:40px;text-align:center">' + r.players.filter((p) => p.score === high).map((p) => esc(p.name)).join(" & ") + " " + (r.players.filter((p) => p.score === high).length > 1 ? "share the win!" : "wins!") + "</h2>" + scores(r, false) + (r.host ? '<button class="btn primary" id="again">Another game? \u2192</button>' : '<p class="wait">The host can start a rematch.</p>');
  }
  s += (error ? '<div class="error" role="alert">' + esc(error) + "</div>" : "") + '<p><button class="mini" id="leave">Leave this room</button><span class="muted" id="connection"></span></p></div>';
  app.innerHTML = s;
  timer();
  for (const action of ["start", "next", "again"]) {
    const el = document.getElementById(action);
    if (el) el.onclick = () => act(action);
  }
  document.getElementById("copy").onclick = async () => {
    try {
      await navigator.clipboard.writeText(location.origin + "/?room=" + r.code);
      document.getElementById("copy").textContent = "Invite copied \u2713";
    } catch {
      document.getElementById("copy").textContent = location.origin + "/?room=" + r.code;
    }
  };
  document.getElementById("leave").onclick = () => {
    localStorage.removeItem("wst-session");
    session = null;
    room = null;
    error = "";
    render();
  };
  const form = document.getElementById("answer");
  if (form) form.onsubmit = (e) => {
    e.preventDefault();
    act("answer", { answer: new FormData(form).get("answer") });
  };
  document.querySelectorAll("[data-card]").forEach((el) => el.onchange = () => guess[el.dataset.card] = el.value);
  document.querySelectorAll("[data-choice]").forEach((el) => el.onclick = () => {
    guess.choice = el.dataset.choice;
    document.querySelectorAll("[data-choice]").forEach((b) => b.classList.toggle("selected", b === el));
  });
  const lock = document.getElementById("lock");
  if (lock) lock.onclick = () => act("guess", { guesses: guess });
}
function scores(r, delta) {
  return [...r.players].sort((a, b) => b.score - a.score).map((p, i) => '<div class="card rank"><span>' + (i + 1) + ". " + esc(p.name) + (delta ? '<div class="muted">' + r.delta[p.id].correct + " correct \xB7 " + r.delta[p.id].fooled + " fooled</div>" : "") + "</span><strong>" + p.score + (delta ? '<small style="color:var(--purple);font-size:13px"> +' + r.delta[p.id].total + "</small>" : "") + "</strong></div>").join("");
}
async function act(action, extra = {}) {
  if (busy) return;
  busy = true;
  try {
    const d = await api("action", { ...session, action, round: room.round, ...extra });
    const changed = room.phase !== d.room.phase || room.round !== d.room.round;
    if (changed) guess = {};
    room = d.room;
    error = "";
    render();
  } catch (e) {
    error = e.message;
    const el = document.createElement("div");
    el.className = "error";
    el.setAttribute("role", "alert");
    el.textContent = error;
    app.append(el);
  } finally {
    busy = false;
  }
}
function timer() {
  const el = document.getElementById("timer");
  if (el && room?.deadline) el.textContent = "\u25F7 " + Math.max(0, Math.ceil((room.deadline - Date.now()) / 1e3)) + "s";
}
setInterval(timer, 250);
let polling = false;
async function poll() {
  if (!session || busy || polling) return;
  polling = true;
  try {
    const res = await fetch("/.netlify/functions/game?operation=state&code=" + encodeURIComponent(session.code) + "&id=" + encodeURIComponent(session.id));
    const d = await res.json();
    if (!res.ok) throw Error(d.error);
    const old = room;
    room = d.room;
    if (!old || old.phase !== room.phase || old.round !== room.round) {
      guess = {};
      render();
    } else if (JSON.stringify(old.players) !== JSON.stringify(room.players) || !!old.myAnswer !== !!room.myAnswer || !!old.myGuesses !== !!room.myGuesses) {
      if (room.phase !== "answer" || room.myAnswer) {
        render();
      }
    }
    const c = document.getElementById("connection");
    if (c) c.textContent = "Connected \xB7 updates live";
  } catch (e) {
    const c = document.getElementById("connection");
    if (c) c.textContent = "Reconnecting\u2026 " + e.message;
    else {
      error = e.message;
      session = null;
      localStorage.removeItem("wst-session");
      render();
    }
  } finally {
    polling = false;
  }
}
render();
poll();
setInterval(poll, 1500);
